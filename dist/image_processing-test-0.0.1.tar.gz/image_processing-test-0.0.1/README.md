#image-processing
Description
the package image_processing is used to:
	Processing:
		- Histogram matching
		- Structural similarity
		- Resize image
	Utils:
		- Read Image
		- Save Image
		- Plot result
		- Plot histograms
	

##Installation
	Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name
```bash
pip install image-processing
```


##Author
Matheus Felipe
